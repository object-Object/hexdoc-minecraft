from hexdoc.model import StripHiddenModel


class MinecraftProps(StripHiddenModel):
    version: str
