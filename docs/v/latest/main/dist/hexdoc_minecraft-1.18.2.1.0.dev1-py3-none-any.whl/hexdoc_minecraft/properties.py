from hexdoc.model import StripHiddenModel


class MinecraftProps(StripHiddenModel):
    ref: str
    version: str
