# favicons

Bundled copy of https://github.com/thatmattlove/favicons.

## Why is this vendored?

https://github.com/thatmattlove/favicons/issues/9
