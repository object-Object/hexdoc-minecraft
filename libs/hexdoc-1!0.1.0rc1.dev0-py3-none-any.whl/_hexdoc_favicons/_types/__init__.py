"""Custom type definitions."""

# Project
from .color import Color as Color
from .properties import FaviconProperties as FaviconProperties
