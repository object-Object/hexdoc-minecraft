"""DEPRECATED - This module only exists to reduce the impact of the breaking changes in
`v1!0.1.0rc1`. Do not use it in new code."""
